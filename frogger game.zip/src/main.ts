import { interval, fromEvent, Observable, merge, pipe, concat,   } from "rxjs";
import { map, filter, takeUntil,  tap, repeatWhen, scan, flatMap, take, repeat, delay, switchMap, takeWhile, } from "rxjs/operators";

import "./style.css";

function main() {

  const svg = document.querySelector("#svgCanvas") as SVGElement & HTMLElement;

  // this stores the x,y coordinates of our playable frog
  type Position ={
    x: number;
    y: number;
  }


  // Initial frog location here
  const initialFrogPosition: Position = {x:300, y: 565}; // 300, 565
  const frogPosition: Position = {x:300, y: 565}; // <---- MODIFY THIS IF YOU WISH TO START FURTHER AHEAD ALTHOUGH THIS WILL CAUSE SCORING TO BEHAVING IMPROPERLY


  // Adding our frog
  const frog = document.createElementNS(svg.namespaceURI, "circle");
  frog.setAttribute("r", "15");
  frog.setAttribute("cx", String(frogPosition.x));
  frog.setAttribute("cy", String(frogPosition.y));
  frog.setAttribute("style","fill: #39FF14; stroke: #228B22; stroke-width: 2px; ")
  svg.appendChild(frog);


  // $ indicates variable is an observable stream
  const keydown$ = fromEvent<KeyboardEvent>(document, 'keydown');

  // w = up
  // a = left
  // s = down
  // d = right 
  const moveRight$ = keydown$.pipe(filter(({key}) => key == 'd',  filter(({repeat})=>!repeat)),map(x => [15,0]));  
  const moveLeft$ = keydown$.pipe(filter(({key}) => key == 'a',  filter(({repeat})=>!repeat)),map(x => [-15,0]));   
  const moveUp$ = keydown$.pipe(filter(({key}) => key == 'w',  filter(({repeat})=>!repeat)),map(x => [0,-15]));
  const moveDown$ = keydown$.pipe(filter(({key}) => key == 's',  filter(({repeat})=>!repeat)),map(x => [0,15]));



  // side effects for frog position, and gameboard (score)
  function updateFrog(g: GameBoard, position: Position, coords: number[]): Position {


    // if our x-coordinate target location overshoots canvas width, wrap around
    position.x = position.x + coords[0]  < 0 ? (position.x + coords[0]) + Constants.CanvasSize : (position.x + coords[0]) > Constants.CanvasSize ? (position.x + coords[0]) - Constants.CanvasSize : (position.x + coords[0]);
    
    // y coordinate should not be able to wrap around, stay at top or bottom
    if (position.y + coords[1] > 585){
      position.y = 585;
    }
    else if (position.y + coords[1] < 15){
      position.y = 15;
    }
    else{
      position.y = position.y + coords[1]
    }

    // add 150 or subtract 150 if we travel up and down respectively
    if (coords[1] > 0 && position.y < Board.roadStart && position.y > Board.oceanStart){
      g.currentScore -= 150
    }
    else if (coords[1] < 0 && position.y < Board.roadStart && position.y > Board.oceanStart){
      g.currentScore += 150
    }

                
    return position;
  }



  // impure?
  function moveFrog( position: Position): void{

    frog.setAttribute("cx", String(position.x));
    frog.setAttribute("cy", String(position.y));

  }

  // <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< SECTION TWO >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  // <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<  NPC MOVING OBJECTS >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  

  // << INITIALISING GAMEBOARD >>

  type body = 'Truck' | 'Car' | 'Log' | "FastLog" | 'Piranha' | 'FinishZone'

  type Body = {
    id: string, // id = type of body + obj count
    type: body,
    x: number,
    y: number
    rx: number,
    ry: number,
    width: number,
    height: number,
    style: string // "style", "fill: #ed6db6; stroke: #c43988; stroke-width: 10px;"
    }


  type GameBoard = {
    trucks: Body[],
    cars: Body[],
    logs: Body[],
    fastLogs: Body[],
    piranhas: Body[],
    finishzone: Body[],

    turns: number,
    highScore: number,
    currentScore: number,
    gameOver: boolean,
    oceanCheck: boolean
  }

  const gameBoard: GameBoard = {
    trucks: [],
    cars: [],
    logs: [],
    piranhas: [],
    fastLogs: [],
    finishzone: [],

    highScore: 0,
    currentScore: 0,
    turns: 1,
    gameOver: false,
    oceanCheck: false
  }

  
  const  Constants = {
      CanvasSize: 600,

      TruckCount: 0, // Our first body will have id: 1
      LogCount: 0,
      FastLogCount: 0,
      CarCount: 0,
      PiranhaCount: 0,
      FinishZoneCount: 0,
  
      TruckSpeed: 1,
      CarSpeed: -4,
      LogSpeed: 1,
      FastLogSpeed: -2,
      PiranhaSpeed: 2 , 

    }

  const Board = {
    roadStart: 540,
    oceanStart: 45,
    oceanEnd: 285
  }


// draw a simple rectangle on canvas: useful for static background shapes 
// this function is used to create shapes we will not be interacting with
  function createRectangle(x: number, y: number, color: string, w: number, h: number){
    const shape = document.createElementNS(svg.namespaceURI, "rect");
    Object.entries({
    x: x,
    y: y,
    width: w,
    height: h,
    fill: color
    }).forEach(([key, val]) => shape.setAttribute(key, String(val)));

    svg.appendChild(shape);

  }


// draw body on canvas and create object which holds matching attributes
function createBody(position: Position, body: Body ): Body{

    const shape = document.createElementNS(svg.namespaceURI, "rect");
    Object.entries({
     x: position.x,  
     y: position.y,
     rx: body.rx,
     ry: body.ry,
     width: body.width,
     height: body.height,
    }).forEach(([key, val]) => shape.setAttribute(key, String(val)));

    shape.setAttribute("style", body.style);

    // create our new body : car, fish or log with our new coordinates from generateCoords
    const newBody = structuredClone(body); 

    // increment the id we will use for our body so we can retrieve the element by ID later
    switch (newBody.type){
      case "Car":
        Constants.CarCount += 1; // id = type+objCount
        newBody.id = "Car"+String(Constants.CarCount); 
        break
      case "Truck":
        Constants.TruckCount += 1;
        newBody.id = "Truck"+String(Constants.TruckCount);
        break
      case "Log":
        Constants.LogCount += 1;
        newBody.id = "Log"+ String(Constants.LogCount);
        break
      case "FastLog":
        Constants.FastLogCount += 1;
        newBody.id = "FastLog"+ String(Constants.FastLogCount);
        break
      case "Piranha":
        Constants.PiranhaCount += 1;
        newBody.id = "Piranha"+String(Constants.PiranhaCount);
        break
      case "FinishZone":
          Constants.FinishZoneCount += 1;
          newBody.id = "Finish"+String(Constants.FinishZoneCount);
          break
    }

    newBody.x = position.x;
    newBody.y = position.y;
    shape.id = newBody.id; // both object and svg element will have matching IDs based on number of elements of each type

    svg.appendChild(shape);
 
    return newBody; // return our newly created moving body so we can add to our gameboard

  }

  
// generate coordinates that will space an object of given height and width between the provided limits
function generateCoords(body: Body, ylim: number[], xlim: number[], xspace: number): Position[]{

  const buffer = 40;
  const coords: Position[] = []; // list of Position{x,y} coordinates

  for (var i = xlim[0] + buffer ; i<xlim[1] ; i+= body.width + xspace)
  {
    for (var j = ylim[0]; j<ylim[1] - buffer ; j+= body.height + buffer/2){
      const position: Position= {x: i, y: j};
      coords.push(position);
    }
  }
 
  return coords;
  }

  const safeStringColor = "fill: red; stroke: red; stroke-width: 5px;";

// initialise our gameboard 
  function initialiseGameBoard(g: GameBoard){

    // << SET STYLE ATTRIBUTES FOR OUR ANIMATED NPCS HERE >>
    createRectangle(0, Board.oceanStart,"#51ACF5", Constants.CanvasSize, Constants.CanvasSize/2 - 15); // creates ocean background for logs + steps section
    createRectangle(0, Board.oceanEnd,"#CF9FFF", Constants.CanvasSize, 60); // safe zone in the middle: purple
    createRectangle(0, Board.roadStart,"#CF9FFF", Constants.CanvasSize, 60); // safe zone at start: purple

    const finishBody: Body = { id: "FinishZone0", type: 'FinishZone', x: 0, y: 0, rx: 3, ry: 3, width: 70, height: 36, style: "fill: red; stroke: red; stroke-width: 5px;"} 
    // finishZone should turn green when frog hits

    const truckBody: Body = { id: "Truck0", type: "Truck", x: 0, y: 0, rx: 10, ry: 10, width: 50, height: 30, style: "fill: #ed6db6; stroke: #990033; stroke-width: 5px;"} 
    const carBody: Body = { id: "Car0", type:  "Car", x: 0, y: 0, rx: 10, ry: 10, width: 30, height: 30, style: "fill: #25F9C3; stroke: #1DBCDF; stroke-width: 5px;"} 
    const logBody: Body = { id: "Log0", type: "Log", x: 0, y: 0, rx: 10, ry: 10, width: 100, height: 30, style: "fill: #6E2D05; stroke: #BD500E; stroke-width: 5px;"}
    const fastLogBody: Body = { id: "FastLog0", type: "FastLog", x: 0, y: 0, rx: 10, ry: 10, width: 100, height: 30, style: "fill: #331100; stroke: #6E2D05; stroke-width: 5px;"}
    const piranhaBody: Body = { id: "Piranha0", type: "Piranha", x: 0, y: 0, rx: 10, ry: 10, width: 25, height: 25, style: "fill: #FFAA00; stroke: #FF6C00; stroke-width: 5px;"}
    
    //  WE ARE MODIFYING OUR GAMEBOARD
    const trucks = concat(generateCoords(truckBody, [350, 400], [0, Constants.CanvasSize], 200), 
      generateCoords(truckBody, [450, 550], [0, Constants.CanvasSize], 130)).forEach((position) => {
      g.trucks.push(createBody(position, truckBody));});

    const cars = generateCoords(carBody, [400, 450], [0, Constants.CanvasSize], 250).forEach((position) => {
      g.cars.push(createBody(position, carBody));});

    const logs = concat(generateCoords(logBody, [100, 150], [0, Constants.CanvasSize], 120), 
      generateCoords(logBody, [200, 250], [0, Constants.CanvasSize], 50)).forEach((position) => {
      g.logs.push(createBody(position, logBody));});

    const fastLogs = concat(generateCoords(fastLogBody, [50, 100], [0, Constants.CanvasSize], 50), 
      generateCoords(fastLogBody, [150, 200], [0, Constants.CanvasSize], 75), 
      generateCoords(fastLogBody, [250, 300], [0, Constants.CanvasSize], 150)).forEach((position) => {
      g.fastLogs.push(createBody(position, fastLogBody));});

    
    const piranhas = concat(generateCoords(piranhaBody, [50, 100], [120, 200], 50), 
      generateCoords(piranhaBody, [200, 300], [150, 250], 50), 
      generateCoords(piranhaBody, [100, 150], [350, 400], 50)).forEach((position) => {
      g.piranhas.push(createBody(position, piranhaBody));}); 

    const finish = generateCoords(finishBody, [5, 50], [0, Constants.CanvasSize], 75).forEach((position) => {
      g.finishzone.push(createBody(position, finishBody));});
    

    return g;
  
  }




  // allows npc moving bodies to wrap smoothly around canvas 
  function wrapBody(x: number, speed: number, width: number): number {

    // if speed > 0 objects are moving left to right
    if (speed > 0) {
      if (x+speed + width > Constants.CanvasSize ){
        return -width;
      }
    }

    // if speed < 0, objects are moving right to left
    else if (speed < 0){
      if (x+speed + width < 0) {
        return 600;
      }
    }

    return x + speed;
  }




// the majority of our side effects are performed in this function
// this function controls the movement of all NPC moving bodies, e.g car, truck, piranha as well as collision detection
function updateGameBoard(g: GameBoard, frogPosition: Position): GameBoard{

  
    displayScore(); // update scoreboard

    // we use this variable "oceanCheck" to check if we are in contact with any logs during ocean section
    g.oceanCheck = false; // reset this each time we check              

    g.trucks.forEach(truck => {
      truck.x = wrapBody(truck.x, Constants.TruckSpeed, truck.width); // setting truck object with wrapped new x coordinate so we dont overhoot
      document.getElementById(truck.id)?.setAttribute("x", String(truck.x)); // setting svg truck x coordinate
  
      if (collisionDetection(truck)) { 
        g.gameOver = true; 
      }  
    });

    g.cars.forEach(car => {
      car.x = wrapBody(car.x , Constants.CarSpeed, car.width); 
      document.getElementById(car.id)?.setAttribute("x", String(car.x)); 

      if (collisionDetection(car)){ 
        g.gameOver = true;
       }
    });

    g.logs.forEach(log => {
      log.x = wrapBody(log.x, Constants.LogSpeed, log.width);
      document.getElementById(log.id)?.setAttribute("x", String(log.x)); 

      // when frog collides with log it should stick onto log unless a keypress is detected
      if (collisionDetection(log)){
        g.oceanCheck = true; 
        moveFrog(updateFrog(g, frogPosition, [Constants.LogSpeed, 0])) // side effect performed on our parameter

      }
    });

    g.fastLogs.forEach(fastLog => {
      
      fastLog.x = wrapBody(fastLog.x, Constants.FastLogSpeed, fastLog.width);
      document.getElementById(fastLog.id)?.setAttribute("x", String(fastLog.x)); 

      if (collisionDetection(fastLog)){
        g.oceanCheck = true; 
        moveFrog(updateFrog(g, frogPosition, [Constants.FastLogSpeed, 0])) // side effect performed on our parameter
      }
    });

    // frog must be in contact with at least one log during ocean section y-coordinate = [45,245]
    const frogRadius = 10;
    if (frogPosition.y > Board.oceanStart + frogRadius && frogPosition.y < Board.oceanEnd + frogRadius){
      if (!g.oceanCheck){
        g.gameOver = true; // if we are not in contact with any logs, but are travelling within ocean region , initiate game over sequence

      }
    }

    g.piranhas.forEach(piranha => {
      piranha.x = wrapBody(piranha.x, Constants.PiranhaSpeed, piranha.width);
      document.getElementById(piranha.id)?.setAttribute("x", String(piranha.x));

      if (collisionDetection(piranha)){ 
        g.gameOver = true; 
      }
    }); 

    
    if (g.gameOver) { // <------ calling game over sequence if collision was detected 
       gameOver(g);
      }  

    // check if we have collided with our finish zones
    g.finishzone.forEach(finish => {
      if (collisionDetection(finish) && finish.style == "fill: red; stroke: red; stroke-width: 5px;"){ // cannot use previously comp
        turnCompleted(g, finish); 
      }
    })

    return g

  }


  function collisionDetection(body: Body): Boolean{
    // frogPosition holds our {x,y}
    const frogRadius = 10; // <------- BUFFER IS NEEDED to travel between logs in ocean region
    // checking x position of frog
    if(frogPosition.x >= body.x - frogRadius  && frogPosition.x <= body.x + body.width + frogRadius ){
      // checking y position of frog
      if (frogPosition.y >= body.y - frogRadius && frogPosition.y <= body.y + body.height + frogRadius){
        return true
      }
    }
    return false 
  }




  function displayScore(){
    displayText("currentScore", 15, 590, "black", "Comic Sans", 17,"current score: "+ String(gameBoard.currentScore ));
    displayText("highScore", 400, 590, "black", "Comic Sans", 17, "high score: "+ String(gameBoard.highScore))
  }

  
  
  function gameOver(g: GameBoard): GameBoard{
     
    displayText("gameOver", 150, 310, "red", "Impact", 40, "game over :( ");
    displayText("replay", 120, 340, "black", "Impact", 30, "press spacebar to play again ");
    gameBoard.turns = 1; 

    // if game over, reset finish zones back to red 
    g.finishzone.forEach(finish => {
      finish.style = "fill: red; stroke: red; stroke-width: 5px;" // change color attribute of our gameboard
      document.getElementById(finish.id)?.setAttribute("style", finish.style); // set this change in our svg element
    })

    return g;
  }




  function turnCompleted  (g: GameBoard, finish: Body, ): GameBoard{ 
    
    finish.style = "fill: #39FF14; stroke: #228B22; stroke-width: 5px;"
    document.getElementById(finish.id)?.setAttribute("style",  "fill: #39FF14; stroke: #228B22; stroke-width: 5px;"); // GREEN UPON COMPLETION

    // Display success message for 3 seconds
    displayText("success", 120, 325, "green", "Impact", 50, "success :D");
    interval(3000).subscribe(x => {
      document.getElementById("success")?.remove();
    });

     // move frog back to start
     frogPosition.x = initialFrogPosition.x;
     frogPosition.y = initialFrogPosition.y+30;
     moveFrog(initialFrogPosition); // side effect

     gameBoard.highScore += gameBoard.currentScore; // increment high score with completed turn score
     gameBoard.currentScore = 0; // reset scoreboard
     gameBoard.turns += 1;
    
    // if we have successfully completed 4 tiames, reset finish zones to red and increase difficulty level
    if (gameBoard.turns%4 == 0){
      g.finishzone.forEach(finish => {
        finish.style = "fill: red; stroke: red; stroke-width: 5px;" // change color attribute of our gameboard
        document.getElementById(finish.id)?.setAttribute("style", finish.style); // set this change in our svg element
      })

      // increasing difficulty level: trivial feature 
      Constants.PiranhaSpeed -= 1; // side effects, but what is the point of making a type for my constants
      Constants.FastLogSpeed -= 1;
      Constants.LogSpeed += 1;
      Constants.CarSpeed += 1;

    }

    return g
  }

  


// font-size, font-family need to be set seperately
  function displayText(id: string, x: number, y: number, color: string, fontFamily: string, fontSize: number, textContent: string){
    
    const text = document.createElementNS(svg.namespaceURI, "text") as HTMLElement;
    
    Object.entries({
      id: id,
      x: x,
      y: y,
      fill: color,
      }).forEach(([key, val]) => text.setAttribute(key, String(val)));

    text.setAttribute("font-family", fontFamily);
    text.setAttribute("font-size", String(fontSize))

    text.textContent = textContent;

    if (id != "success") {
      document.getElementById(id)?.remove(); // remove old text (current score is contantly being updated)
    }

    svg.appendChild(text);

  }

  // this function is executed ...
  function reset(g: GameBoard){

    gameBoard.gameOver = false                                

    // move frog back to start
    frogPosition.x = initialFrogPosition.x;
    frogPosition.y = initialFrogPosition.y;
    moveFrog(initialFrogPosition); // side effect

    document.getElementById("replay")?.remove(); // remove replay and game over text
    document.getElementById("gameOver")?.remove(); 

    gameBoard.currentScore = 0; // reset scoreboard

    return g
    
  }



  /// <<< OBSERVABLES and FUNCTIONS WITH SIDE EFFECTS EXECUTED BELOW >>>


  // side effects : writing to DOM
  initialiseGameBoard(gameBoard);

  //objects are passed by reference. So, if you pass a object to a function and change the object inside the function, the object outside also changes

 const gameOverStatus$ = new Observable(function subscribe(subscriber) {
    const tick$ = interval(50).subscribe(tick => {
      if (gameBoard.gameOver == true){ // observable emits an error if gameOver = true, checking every 50 ms
        subscriber.next('game over');
      }});
    });


  // spacebar is pressed while gameOver = true, use tap() to execute reset(gameBoard) function
  const replay$ = keydown$.pipe(filter(({code}) => code == 'Space' , filter(({repeat})=>!repeat))).pipe(takeWhile((x => gameBoard.gameOver == true)), tap(x => {reset(gameBoard)})); // tap = side effects


  const gameMovement$ = merge(interval(50),moveRight$, moveLeft$, moveDown$, moveUp$).pipe(

    takeUntil(gameOverStatus$), // unsubscribe when gameOver = true;
    repeatWhen(pipe(() => replay$)) // resubscribe when replay$ emits a value
    ).subscribe(pipe(coords => {

      if (coords instanceof Array){ // result of mapping keypress -> change in x,y coordinate for frogPosition
        updateFrog(gameBoard, frogPosition, coords as number[]);
        moveFrog(frogPosition); 
      }
      else {
        updateGameBoard(gameBoard, frogPosition);  // otherwise our NPCs will speed up on Keyboard presses
      }
    })); 
 
  svg.insertBefore(frog, null);

}


// The following simply runs your main function on window load.  Make sure to leave it in place.
if (typeof window !== "undefined") {
  window.onload = () => {
    main();
    
  };
}

